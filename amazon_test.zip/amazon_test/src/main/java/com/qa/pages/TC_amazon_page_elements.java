package com.qa.pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.io.File;

@SuppressWarnings("unused")
public class TC_amazon_page_elements {
	 WebDriver driver ; 
	 
	 @FindBy(xpath = "//*[@id=\"twotabsearchtextbox\"]")
	 WebElement search_box ;
     public WebElement search() {
		return search_box;
     }
     
     @FindBy(xpath ="//*[@id=\"nav-xshop\"]/a[2]" )
     WebElement deals_today ;
     public WebElement deals() {
    	 return deals_today ; 
     }
     
     @FindBy (xpath ="//*[@id=\"nav-search-submit-button\"]")
     WebElement search_button ;
     public WebElement search_button() {
    	 return search_button ;
     }
     @FindBy (xpath = "//*[@id=\"grid-main-container\"]/div[2]/span[4]/span/ul/li[3]/div/a/span")
     WebElement lightning_deals;
     public WebElement lightning_deals () {
     return lightning_deals ; 
     }
     
     @FindBy (xpath = "//*[@id=\"nav-link-accountList\"]/span")
     WebElement sign_in ; 
     public WebElement sign_in () {
    	 return sign_in ; 
     }
     
     @FindBy (xpath = "//*[@id=\"ap_email\"]")
     WebElement email_log ; 
     public WebElement email_log () {
    	 return email_log;
     }
     
     @FindBy (xpath = "//*[@id=\"continue\"]")
     WebElement log_next ; 
     public WebElement log_next () {
    	 return log_next ; 
     }
     
     @FindBy (xpath = "//*[@id=\"ap_password\"]")
     WebElement password_box ;
     public WebElement password_box() {
    	 return password_box;
     }
     
     @FindBy (xpath = "//*[@id=\"signInSubmit\"]")
     WebElement log_in ; 
     public WebElement log_in () {
    	 return log_in ;
     }
     
     @FindBy (linkText = "https://www.amazon.in/gp/cart/view.html?ref_=nav_cart")
     WebElement cart_loc ; 
     public WebElement cart_loc () {
    	 return cart_loc; 
     }
     
     
     public TC_amazon_page_elements(WebDriver driver) {
 		this.driver=driver;
 		PageFactory.initElements(driver, this);
 	}
 
     
}
