package com.qa.test_scripts;
import com.qa.pages.TC_amazon_page_elements;
import com.qa.test_scripts.TC_amazon_test_base;
import com.qa.utility.Excel_utility;

import java.io.IOException;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import org.openqa.selenium.WebDriver;


public class TC_amazon_addtocart extends TC_amazon_test_base {
	public void TC_Amazon_HomeSearch(String name) throws InterruptedException, IOException {
		TC_amazon_page_elements search_page = new TC_amazon_page_elements(null);
		SoftAssert SAssert =new SoftAssert();
		search_page.wait(3000);
		search_page.cart_loc().click();
		search_page.wait(3000);

		
	}

	}
