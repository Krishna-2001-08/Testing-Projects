package com.qa.test_scripts;
import com.qa.pages.TC_amazon_page_elements;
import com.qa.test_scripts.TC_amazon_test_base;
import com.qa.utility.Excel_utility;

import java.io.IOException;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import org.openqa.selenium.WebDriver;


public class TC_amazon_search extends TC_amazon_test_base {
	@SuppressWarnings("unused")
	@Test(dataProvider="getdata")
	public void TC_Amazon_HomeSearch(String name) throws InterruptedException, IOException {
		TC_amazon_page_elements search_page = new TC_amazon_page_elements(null);
		SoftAssert SAssert =new SoftAssert();
		search_page.cart_loc().click();

		

	}
	@DataProvider
	public Object[][] getdata() throws IOException
	{
		String xFile="C:\\Program Files (x86)\\Java\\amazon_test\\src\\main\\java\\com\\qa\\test_data\\test.xlsx";
		String Xsheet="Sheet1";
		int rowCount = Excel_utility.getRowCount(xFile, Xsheet);
		int cellcount = Excel_utility.getCellCount(xFile,Xsheet,rowCount);
		String[][] data=new String[rowCount][cellcount];
		for(int i=1;i<=rowCount;i++) 
			{
				for(int j=0;j<cellcount;j++) {
						data[i-1][j]= Excel_utility.getCellData(xFile, Xsheet, i, j);
		
				}
			}
		return data;
		}
}